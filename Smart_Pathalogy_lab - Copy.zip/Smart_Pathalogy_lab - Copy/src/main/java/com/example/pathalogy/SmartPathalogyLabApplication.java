package com.example.pathalogy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartPathalogyLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartPathalogyLabApplication.class, args);
	}

}
