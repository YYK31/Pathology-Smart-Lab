package com.example.pathalogy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartPathalogyLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
